package com.example.testcompass;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Menu;
import android.widget.TextView;

public class MainActivity extends Activity {

	private SensorManager sensorManager;
	private Sensor orientation;
	private SensorEventListener orientationListener;

	double azimuth;
	double pitch;
	double roll;

	TextView azimuthTextView;
	TextView pitchTextView;
	TextView rollTextView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		azimuthTextView = (TextView) findViewById(R.id.azimuthTextView);
		pitchTextView = (TextView) findViewById(R.id.pitchTextView);
		rollTextView = (TextView) findViewById(R.id.rollTextView);

		// For 2.2 : TYPE_ORIENTATION (but deprecated and probably replaced by
		// TYPE_ROTATION_VECTOR), TYPE_GYROSCOPE declared but not fully
		// available until 2.3.

		sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		orientation = sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);

		// Define a listener that responds to orientation updates.
		orientationListener = new SensorEventListener() {
			public void onSensorChanged(SensorEvent event) {
				azimuth = event.values[0];
				pitch = event.values[1];
				roll = event.values[2];
				azimuthTextView.setText(String.valueOf(azimuth));
				pitchTextView.setText(String.valueOf(pitch));
				rollTextView.setText(String.valueOf(roll));
			}

			public void onAccuracyChanged(Sensor sensor, int accuracy) {
			}
		};

		sensorManager.registerListener(orientationListener, orientation, SensorManager.SENSOR_DELAY_NORMAL);
	}

	@Override
	public void onDestroy() {
		super.onDestroy(); // Always call the superclass method first.

		sensorManager.unregisterListener(orientationListener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
}
