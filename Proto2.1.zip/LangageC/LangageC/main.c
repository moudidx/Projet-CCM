//
//  main.c
//  LangageC
//
//  Created by Romain DA CANAL on 02/11/2016.
//  Copyright (c) 2016 Romain DA CANAL. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h> //pour sleep()
#include "Recup.h"
#include "Nbre_premier.h"
#include "AES_256.h"


long GenerateurRSA();



/*
 *
 */
int main(int argc, char** argv) {
    int i;
    int k;
    srand(time(NULL));
    uint8_t TEXT[SIZETEXT]={0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff};
    uint8_t Key [SIZEKEY]={0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,0x1a,0x1b,0x1c,0x1d,0x1e,0x1f};
    uint8_t Key_Schedule [Nb*(Nr+1)][4];
    //uint8_t VI [SIZEVI];
    //Key_creation(&Key[0], SIZEKEY);
    //VI_creation(&VI[0], SIZEVI);
    Key_Expension(&Key[0],Key_Schedule);
    Cipher(&TEXT[0], Key_Schedule);
    
    /*rnddata();
    char** donnees;
    donnees=Recupcap();
    Recupboite(donnees);*/
    /*char b[16]="helloworldhello";
    int c[16];
    for(int i=0;i<16;i++){
        c[i]=(int)b[i];
        printf("%i",c[i]);
    }*/
  //  uint8_t donnees=255;
  //  donnees=dec_to_hex(donnees);
  //  printf("%hhX",donnees);
    

    //long long a=nombrepremier();
    //printf("%lld",a);*/
    //return (EXIT_SUCCESS);
    
    /*for (i=0;i<Nb*(Nr+1);i++){
        for (k=0;k<4;k++){
            printf("ligne %i colonne %i %X\n",i,k,*(Key_Schedule[i]+k));
        }
    }*/
    
}



