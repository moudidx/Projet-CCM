//
//  Nbre_premier.h
//  LangageC
//
//  Created by Romain DA CANAL on 10/11/2016.
//  Copyright (c) 2016 Romain DA CANAL. All rights reserved.
//

#ifndef __LangageC__Nbre_premier__
#define __LangageC__Nbre_premier__

#include <stdio.h>
long long nombrepremier();
long long mul(long long a,long long b,long long c);
long long mod(long long a,long long b,long long c);
int Miller(long long p,long long it);

#endif /* defined(__LangageC__Nbre_premier__) */
