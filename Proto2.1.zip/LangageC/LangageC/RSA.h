//
//  RSA.h
//  LangageC
//
//  Created by Romain DA CANAL on 10/11/2016.
//  Copyright (c) 2016 Romain DA CANAL. All rights reserved.
//

#ifndef __LangageC__RSA__
#define __LangageC__RSA__

#include <stdio.h>
long GenerateurRSA();
#endif /* defined(__LangageC__RSA__) */
