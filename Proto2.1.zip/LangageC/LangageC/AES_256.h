//
//  AES_256.h
//  LangageC
//
//  Created by Romain DA CANAL on 21/11/2016.
//  Copyright (c) 2016 Romain DA CANAL. All rights reserved.
//

#ifndef __LangageC__AES_256__
#define __LangageC__AES_256__
#define SIZEKEY 32
#define SIZEVI 16
#define SIZETEXT 16
//#define VALUEWORD 4294967295
#define Nk 8    //Key length (words)
#define Nb 4    //Block Size (words)
#define Nr 14   //Number of Rounds

#include <stdio.h>

int Cipher(uint8_t *, uint8_t (*word)[4]);
//uint8_t , uint8_t (*word)[4]);
int Key_creation(uint8_t*,int);
int VI_creation(uint8_t*,int);
int SubWord(uint8_t*);
int RotWord(uint8_t*);
int Key_Expension(uint8_t*,uint8_t (*word)[4]);
int Create_KEY_VI();
int SubBytes(uint8_t (*state)[Nb]);
int AddRoundKey(uint8_t (*state)[Nb],uint8_t (*word)[4], int);

#endif /* defined(__LangageC__AES_256__) */
