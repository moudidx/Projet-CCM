//
//  Recup.c
//  LangageC
//
//  Created by Romain DA CANAL on 10/11/2016.
//  Copyright (c) 2016 Romain DA CANAL. All rights reserved.
//

#include "Recup.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NBLIGNE 4

char** Recupcap(){
    FILE* fichier = NULL;
    fichier = fopen("Donnees.txt","r");
    char** donnees=NULL;
    if (fichier!=NULL){
        donnees = malloc(NBLIGNE*sizeof(char*));
        int i = 0;
        for(i=0;i<NBLIGNE;i++){
            donnees[i] = malloc(100*sizeof(char));
        }
        i=0;
        while(fgets(donnees[i], 100, fichier)!=NULL && i<NBLIGNE){
            i++;
        }
    }
    fclose(fichier);
    
    return donnees;
}

int Recupboite(char** donnees){
    char k;
    if (donnees!=NULL){
        printf("appuyez sur r pour recuperer les donnees (q pour quitter)\n");
        do {
            scanf("%c",&k);
            if (k=='r'){
                int i=0;
                while(i<NBLIGNE){
                    printf("%s",donnees[i]);
                    i++;
                }
                printf("\n");
            }
            else if(k=='q'){
                break;
            }
            else{
                printf("commande incorrecte\n");
            }
        }while(k!='r');
    }
    return (EXIT_SUCCESS);
}

void rnddata(){
    FILE* fichier = NULL;
    fichier = fopen("Donnees.txt","w+");
    time_t t;
    srand((unsigned) time(&t));
    char c;
    if(fichier != NULL){
        int i = 0;
        for(i=0;i<30;i++){
            c = (rand() % 2)+48;
            fputc(c,fichier);
        }
        fputc('\n', fichier);
        for(i=0;i<30;i++){
            c = (rand() % 2)+48;
            fputc(c,fichier);
        }
        fputc('\n', fichier);
        for(i=0;i<10;i++){
            c = (rand() % 10)+48;
            fputc(c,fichier);
        }
        fputc('\n', fichier);
        for(i=0;i<5;i++){
            c = (rand() % 10) + 48;
            fputc(c,fichier);
        }
    }
    fclose(fichier);
}

uint8_t dec_to_hex(uint8_t decimal){
    uint8_t quotient;
    int i=3,temp;
    char HexaChar[5];
    HexaChar[0]='0';
    HexaChar[1]='x';
    HexaChar[4]='\0';
    quotient=decimal;
    while(quotient!=0){
        temp =quotient % 16;
        if( temp < 10){
            temp=(char)temp;
            temp =temp + 48;
        }
        else{
            temp=(char)temp;
            temp = temp + 55;
        }
        quotient/=16;
        HexaChar[i]=temp;
        i--;
    }
    uint8_t IntChar=(uint8_t)strtol(HexaChar,NULL,16);
    return IntChar;
    }


