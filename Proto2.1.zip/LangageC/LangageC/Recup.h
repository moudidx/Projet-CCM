//
//  Recup.h
//  LangageC
//
//  Created by Romain DA CANAL on 10/11/2016.
//  Copyright (c) 2016 Romain DA CANAL. All rights reserved.
//

#ifndef __LangageC__Recup__
#define __LangageC__Recup__

#include <stdio.h>
char** Recupcap();
int Recupboite(char** donnees);
void rnddata();
uint8_t dec_to_hex(uint8_t donnees);
#endif /* defined(__LangageC__Recup__) */
